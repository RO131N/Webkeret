export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyDX4an3Lo82G9vW7BB-WfjZrZ1DiT1LJdQ",
    authDomain: "c7ljs7-autobizt.firebaseapp.com",
    projectId: "c7ljs7-autobizt",
    storageBucket: "c7ljs7-autobizt.appspot.com", 
    messagingSenderId: "820162048327",
    appId: "1:820162048327:web:c678093e3da49f2c6c5c62",
    measurementId: "G-3PKGYFG0KY"
  }
};
