import { ToEuroPipe } from './to-euro.pipe';

describe('ToEuroPipe', () => {
  it('create an instance', () => {
    const pipe = new ToEuroPipe();
    expect(pipe).toBeTruthy();
  });
});
