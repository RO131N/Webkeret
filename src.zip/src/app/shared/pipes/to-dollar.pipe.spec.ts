import { ToDollarPipe } from './to-dollar.pipe';

describe('ToDollarPipe', () => {
  it('create an instance', () => {
    const pipe = new ToDollarPipe();
    expect(pipe).toBeTruthy();
  });
});
