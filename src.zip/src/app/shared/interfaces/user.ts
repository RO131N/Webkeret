export interface User {
  name: string;
  birthday: string;
  email: string;
  city: string;
  telNumber: string;
}
